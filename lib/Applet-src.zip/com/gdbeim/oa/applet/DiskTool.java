/*** Eclipse Class Decompiler plugin, copyright (c) 2012 Chao Chen (cnfree2000@hotmail.com) ***/
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) fieldsfirst noctor radix(10) lradix(10) 
// Source File Name:   DiskTool.java

package com.gdbeim.oa.applet;

import java.io.*;

public class DiskTool {

	private DiskTool() {
	}

	public static long getFreeDiskSpace(String dirName)
    {
        Process process;
        String temp = "";
        if(dirName.indexOf(":") > 0)
            temp = dirName.substring(0, dirName.indexOf(":") + 1);
        System.out.println(temp);
        String os = System.getProperty("os.name");
        String command;
        if(os.startsWith("Windows"))
            command = "cmd.exe /c dir " + temp;
        else
            command = "command.com /c dir " + temp;
        Runtime runtime = Runtime.getRuntime();
        process = null;
        process = runtime.exec(command);
label0:
        {
            if(process == null)
                return -1L;
            String freeSpace;
            String items[];
            int index;
            long bytes;
            NumberFormatException numberformatexception;
            try
            {
                BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                for(freeSpace = null; (line = in.readLine()) != null; freeSpace = line);
                if(freeSpace != null)
                    break label0;
                System.out.println("freeSpace is null");
            }
            catch(Exception exception)
            {
                System.out.println("exception:" + exception);
                return -1L;
            }
            return -1L;
        }
        process.destroy();
        freeSpace = freeSpace.trim();
        freeSpace = freeSpace.replaceAll("\\.", "");
        freeSpace = freeSpace.replaceAll(",", "");
        items = freeSpace.split(" ");
        index = 1;
          goto _L1
_L3:
        bytes = Long.parseLong(items[index++]);
        return bytes;
        numberformatexception;
_L1:
        if(index < items.length) goto _L3; else goto _L2
_L2:
        System.out.println("testing is -1");
        return -1L;
    }

	public static void main(String args[]) {
		System.out.println(getFreeDiskSpace("d:"));
	}

	public static String createFolder(String folderPath) {
		String txt = folderPath;
		try {
			File myFilePath = new File(txt);
			txt = folderPath;
			if (!myFilePath.exists())
				myFilePath.mkdir();
		} catch (Exception e) {
			System.out.println("\u521B\u5EFA\u76EE\u5F55\u64CD\u4F5C\u51FA\u9519");
		}
		return txt;
	}

	public static boolean checkPathExists(String folderPath) {
		boolean isExists = false;
		try {
			File myFilePath = new File(folderPath);
			isExists = myFilePath.exists();
		} catch (Exception e) {
			System.out.println("\u76EE\u5F55\u68C0\u67E5\u51FA\u9519");
		}
		return isExists;
	}
}


/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\enixlin\git\Jrrc_MialClient\lib\Applet.jar
	Total time: 35 ms
	Jad reported messages/errors:
Couldn't fully decompile method getFreeDiskSpace
Couldn't resolve all exception handlers in method getFreeDiskSpace
	Exit status: 0
	Caught exceptions:
*/