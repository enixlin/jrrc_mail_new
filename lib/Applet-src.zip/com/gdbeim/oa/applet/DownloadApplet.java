/*** Eclipse Class Decompiler plugin, copyright (c) 2012 Chao Chen (cnfree2000@hotmail.com) ***/
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) fieldsfirst noctor radix(10) lradix(10) 
// Source File Name:   DownloadApplet.java

package com.gdbeim.oa.applet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

// Referenced classes of package com.gdbeim.oa.applet:
//            ProgressListener, HttpGet, DownloadTask, DiskTool, 
//            DownloadFeedback

public class DownloadApplet extends JApplet implements ActionListener, ProgressListener {

	private boolean isClear;
	private static final long serialVersionUID = 1L;
	private String serverAddress;
	private JPanel pane;
	private JScrollPane scrolling;
	private JTextPane infoBox;
	private JTextField directoryField;
	private DownloadFeedback feedback;
	private JButton butLoad;
	private JButton butChoose;
	private JFileChooser fileChooser;
	private JLabel tipsLabel;
	private JLabel direLabel;
	private DownloadTask task;
	private JProgressBar progressBar;
	private JProgressBar currentProgressBar;
	private JCheckBox jCheckBox;
	private JLabel totalLabel;
	private JLabel currentLabel;
	private String strUserId;
	StringBuffer faultInfo;

	public DownloadApplet() {
		isClear = false;
		serverAddress = null;
		pane = null;
		scrolling = null;
		infoBox = null;
		directoryField = null;
		feedback = null;
		butLoad = null;
		butChoose = null;
		tipsLabel = null;
		direLabel = null;
		task = null;
		progressBar = new JProgressBar();
		currentProgressBar = new JProgressBar();
		jCheckBox = null;
		totalLabel = null;
		currentLabel = null;
		strUserId = "";
		faultInfo = new StringBuffer(
				"\u4E0B\u5217\u90AE\u4EF6\u8F6C\u79FB\u5931\u8D25,\u8BF7\u91CD\u65B0\u8F6C\u79FB\u6216\u8005\u624B\u5DE5\u5907\u4EFD:\n");
	}

	public void init() {
		try {
			serverAddress = getParameter("serverAddress");
			resize(400, 300);
			if (serverAddress == null)
				serverAddress = "http://localhost:8081/oa";
			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		pane = new JPanel();
		pane.setBounds(new Rectangle(0, 0, 500, 325));
		pane.setLayout(null);
		pane.setBorder(BorderFactory.createEtchedBorder(1));
		pane.setBackground(Color.WHITE);
		direLabel = new JLabel("\u4FDD\u5B58\u5230:");
		direLabel.setBounds(new Rectangle(15, 10, 295, 30));
		pane.add(direLabel);
		directoryField = new JTextField();
		directoryField.setBounds(new Rectangle(65, 10, 225, 30));
		pane.add(directoryField);
		butChoose = new JButton();
		butChoose.setBounds(new Rectangle(305, 10, 80, 30));
		butChoose.setText("\u9009\u62E9\u76EE\u5F55");
		butChoose.addActionListener(this);
		pane.add(butChoose);
		jCheckBox = new JCheckBox();
		jCheckBox.setBounds(new Rectangle(15, 50, 220, 30));
		jCheckBox.setText("\u4E0B\u8F7D\u5B8C\u6210\u540E\u5220\u9664\u670D\u52A1\u5668\u7AEF\u7684\u90AE\u4EF6");
		jCheckBox.setBackground(Color.WHITE);
		pane.add(jCheckBox);
		butLoad = new JButton();
		butLoad.setBounds(new Rectangle(305, 50, 80, 30));
		butLoad.setText("\u4E0B\u8F7D");
		butLoad.addActionListener(this);
		pane.add(butLoad);
		tipsLabel = new JLabel("\u4E0B\u8F7D\u4EFB\u52A1\u7EDF\u8BA1:");
		tipsLabel.setBounds(new Rectangle(16, 75, 295, 30));
		pane.add(tipsLabel);
		infoBox = new JTextPane();
		infoBox.setText("");
		infoBox.setEditable(false);
		scrolling = new JScrollPane(infoBox);
		scrolling.setBounds(new Rectangle(15, 105, 370, 120));
		pane.add(scrolling);
		totalLabel = new JLabel("\u5168\u90E8\u8FDB\u5EA6");
		totalLabel.setBounds(new Rectangle(15, 235, 55, 25));
		pane.add(totalLabel);
		progressBar.setBounds(new Rectangle(70, 235, 315, 22));
		progressBar.setStringPainted(true);
		progressBar.setMinimum(0);
		pane.add(progressBar);
		currentLabel = new JLabel("\u5F53\u524D\u8FDB\u5EA6");
		currentLabel.setBounds(new Rectangle(15, 265, 55, 25));
		pane.add(currentLabel);
		currentProgressBar.setBounds(new Rectangle(70, 265, 315, 22));
		currentProgressBar.setStringPainted(true);
		currentProgressBar.setMinimum(0);
		pane.add(currentProgressBar);
		fileChooser = new JFileChooser("d:\\");
		fileChooser.setFileSelectionMode(1);
		fileChooser.setFont(new Font("\u5B8B\u4F53", 0, 12));
		fileChooser.setDialogTitle("\u9009\u62E9\u90AE\u4EF6\u4FDD\u5B58\u76EE\u5F55");
		setContentPane(pane);
	}

	public void getDownLoadList(String startDate, String endDate, String userId) {
		try {
			strUserId = userId;
			infoBox.setText("\u8BF7\u7A0D\u5019...");
			HttpGet instance = new HttpGet();
			String url = serverAddress + "/messageDownload?method=getDownList" + "&startDate=" + startDate + "&endDate="
					+ endDate + "&userId=" + userId;
			System.out.println("url=" + url);
			task = instance.getDownloadTask(url);
			displayDownInfo();
		} catch (Exception err) {
			System.out.println("getDownLoadList error:" + err);
		}
	}

	private void displayDownInfo() {
		StringBuffer info = new StringBuffer("");
		int emailCout = task.getReceiveList().size() + task.getDraftList().size() + task.getSendList().size()
				+ task.getWasteList().size();
		int attachCount = task.getReceiveAttachList().size() + task.getDraftAttachList().size()
				+ task.getSendAttachList().size() + task.getWasteAttachList().size();
		info.append("\u6536\u4EF6\u7BB1[").append(task.getReceiveList().size()).append("]\u9644\u4EF6[")
				.append(task.getReceiveAttachList().size()).append("]\n").append("\u53D1\u4EF6\u7BB1[")
				.append(task.getSendList().size()).append("]\u9644\u4EF6[").append(task.getSendAttachList().size())
				.append("]\n").append("\u8349\u7A3F\u7BB1[").append(task.getDraftList().size()).append("]\u9644\u4EF6[")
				.append(task.getDraftAttachList().size()).append("]\n").append("\u5E9F\u4EF6\u7BB1[")
				.append(task.getWasteList().size()).append("]\u9644\u4EF6[").append(task.getWasteAttachList().size())
				.append("]\n").append("\u5171\u8BA1\u90AE\u4EF6[").append(emailCout).append("]\u5C01,\u9644\u4EF6[")
				.append(attachCount).append("]\u4E2A.\n");
		info.append("\u9700\u8981\u78C1\u76D8\u7A7A\u95F4:[").append(task.getTotalFileSize() / 1048576L).append("]MB");
		infoBox.setText(info.toString());
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == butLoad) {
			if (task == null || task.isEmpty()) {
				JOptionPane.showMessageDialog(pane, "\u4E0B\u8F7D\u5217\u8868\u4E3A\u7A7A");
				return;
			}
			if ("".equals(directoryField.getText().trim())) {
				JOptionPane.showMessageDialog(pane, "\u8BF7\u6307\u5B9A\u90AE\u4EF6\u4FDD\u5B58\u76EE\u5F55!");
				return;
			}
			if (!DiskTool.checkPathExists(directoryField.getText())) {
				JOptionPane.showMessageDialog(pane, "\u90AE\u4EF6\u4FDD\u5B58\u76EE\u5F55\u4E0D\u5B58\u5728!");
				return;
			}
			long emailSpace = task.getTotalFileSize();
			System.out.println("emailSpace:" + emailSpace);
			long dirSpace = DiskTool.getFreeDiskSpace(directoryField.getText());
			System.out.println("dirSpace:" + dirSpace);
			long restSpace = dirSpace - emailSpace;
			if (dirSpace == -1L) {
				int value = JOptionPane.showConfirmDialog(pane,
						"\u68C0\u67E5\u78C1\u76D8\u7A7A\u95F4\u5931\u8D25,\u8BF7\u786E\u4FDD\u78C1\u76D8\u7A7A\u95F4\u8DB3\u591F!",
						"\u63D0\u793A", 0);
				if (value == 1)
					return;
			} else if (restSpace < 0L) {
				JOptionPane.showMessageDialog(pane,
						"\u6240\u9009\u76EE\u5F55\u7A7A\u95F4\u4E0D\u8DB3,\u8BF7\u91CD\u65B0\u9009\u62E9!");
				return;
			}
			if (dirSpace != -1L && directoryField.getText().startsWith("C") && restSpace < 209715200L) {
				JOptionPane.showMessageDialog(pane,
						"\u4E0B\u8F7D\u5B8C\u6210\u540EC\u76D8\u7A7A\u95F4\u5C0F\u4E8E200MB,\u8BF7\u91CD\u65B0\u9009\u62E9!");
				return;
			}
			if (jCheckBox.isSelected())
				JOptionPane.showMessageDialog(pane,
						"\u90AE\u4EF6\u5907\u4EFD\u5230\u672C\u5730\u540E,\u670D\u52A1\u7AEF\u7684\u5BF9\u5E94\u90AE\u4EF6\u5C06\u88AB\u6E05\u9664,\u8BF7\u5230\u672C\u5730\u6587\u4EF6\u6D4F\u89C8.");
			butLoad.setEnabled(false);
			doDownload();
		} else if (e.getSource() == butChoose) {
			fileChooser.showSaveDialog(this);
			if (fileChooser.getSelectedFile() != null)
				directoryField.setText(fileChooser.getSelectedFile().getPath());
		}
	}

	private void doDownload() {
		HttpGet instance = new HttpGet();
		Long mailSize = new Long(4096L);
		feedback = new DownloadFeedback();
		java.util.List temp = task.getReceiveList();
		String filePath = DiskTool.createFolder(directoryField.getText() + "/\u6536\u4EF6\u7BB1");
		for (int i = 0; i < temp.size(); i++) {
			Object obj[] = (Object[]) temp.get(i);
			String url = serverAddress + "/messageDownload?method=getContent&messageid=" + obj[0];
			java.util.List attachIds = new ArrayList();
			long attachSize = 0L;
			java.util.List temp2 = task.getReceiveAttachList();
			for (int j = 0; j < temp2.size(); j++) {
				Object obj2[] = (Object[]) temp2.get(j);
				Long id = (Long) obj2[4];
				String attachName = (String) obj2[1];
				Long aSize = (Long) obj2[3];
				if (id.longValue() == ((Long) obj[0]).longValue()) {
					String attachUrl = serverAddress + "//messageFileDown?id=" + obj2[0] + ";"
							+ DiskTool.createFolder(filePath + "/\u9644\u4EF6") + "/" + attachName;
					attachIds.add(attachUrl);
					attachSize += aSize.longValue();
				}
			}

			instance.addItem(url, filePath + "/" + obj[1] + ".html", new Long(mailSize.longValue() + attachSize),
					"receive", attachIds);
			feedback.addReceive((Long) obj[0]);
		}

		temp = task.getSendList();
		filePath = DiskTool.createFolder(directoryField.getText() + "/\u53D1\u4EF6\u7BB1");
		for (int i = 0; i < temp.size(); i++) {
			Object obj[] = (Object[]) temp.get(i);
			String url = serverAddress + "/messageDownload?method=getContent&messageid=" + obj[0];
			java.util.List attachIds = new ArrayList();
			long attachSize = 0L;
			java.util.List temp2 = task.getSendAttachList();
			for (int j = 0; j < temp2.size(); j++) {
				Object obj2[] = (Object[]) temp2.get(j);
				Long id = (Long) obj2[4];
				String attachName = (String) obj2[1];
				Long aSize = (Long) obj2[3];
				if (id.longValue() == ((Long) obj[0]).longValue()) {
					String attachUrl = serverAddress + "//messageFileDown?id=" + obj2[0] + ";"
							+ DiskTool.createFolder(filePath + "/\u9644\u4EF6") + "/" + attachName;
					attachIds.add(attachUrl);
					attachSize += aSize.longValue();
				}
			}

			instance.addItem(url, filePath + "/" + obj[1] + ".html", new Long(mailSize.longValue() + attachSize),
					"send", attachIds);
			feedback.addSend((Long) obj[0]);
		}

		temp = task.getDraftList();
		filePath = DiskTool.createFolder(directoryField.getText() + "/\u8349\u7A3F\u7BB1");
		for (int i = 0; i < temp.size(); i++) {
			Object obj[] = (Object[]) temp.get(i);
			String url = serverAddress + "/messageDownload?method=getContent&messageid=" + obj[0];
			java.util.List attachIds = new ArrayList();
			long attachSize = 0L;
			java.util.List temp2 = task.getDraftAttachList();
			for (int j = 0; j < temp2.size(); j++) {
				Object obj2[] = (Object[]) temp2.get(j);
				Long id = (Long) obj2[4];
				String attachName = (String) obj2[1];
				Long aSize = (Long) obj2[3];
				if (id.longValue() == ((Long) obj[0]).longValue()) {
					String attachUrl = serverAddress + "//messageFileDown?id=" + obj2[0] + ";"
							+ DiskTool.createFolder(filePath + "/\u9644\u4EF6") + "/" + attachName;
					attachIds.add(attachUrl);
					attachSize += aSize.longValue();
				}
			}

			instance.addItem(url, filePath + "/" + obj[1] + ".html", new Long(mailSize.longValue() + attachSize),
					"draft", attachIds);
			feedback.addDraft((Long) obj[0]);
		}

		temp = task.getWasteList();
		long attachSize = 0L;
		filePath = DiskTool.createFolder(directoryField.getText() + "/\u5E9F\u4EF6\u7BB1");
		for (int i = 0; i < temp.size(); i++) {
			Object obj[] = (Object[]) temp.get(i);
			String url = serverAddress + "/messageDownload?method=getContent&messageid=" + obj[0];
			java.util.List attachIds = new ArrayList();
			java.util.List temp2 = task.getWasteAttachList();
			for (int j = 0; j < temp2.size(); j++) {
				Object obj2[] = (Object[]) temp2.get(j);
				Long id = (Long) obj2[4];
				String attachName = (String) obj2[1];
				Long aSize = (Long) obj2[3];
				if (id.longValue() == ((Long) obj[0]).longValue()) {
					String attachUrl = serverAddress + "//messageFileDown?id=" + obj2[0] + ";"
							+ DiskTool.createFolder(filePath + "/\u9644\u4EF6") + "/" + attachName;
					attachIds.add(attachUrl);
					attachSize += aSize.longValue();
				}
			}

			instance.addItem(url, filePath + "/" + obj[1] + ".html", new Long(mailSize.longValue() + attachSize),
					"waste", attachIds);
			feedback.addWaste((Long) obj[0]);
		}

		instance.downLoadByList(this);
	}

	public void deleteFeedBack(boolean isSuccess, String type, Long id) {
		if (isSuccess && jCheckBox.isSelected()) {
			HttpGet instance = new HttpGet();
			DownloadFeedback fd = new DownloadFeedback();
			if ("receive".equals(type))
				fd.addReceive(id);
			if ("send".equals(type))
				fd.addSend(id);
			if ("draft".equals(type))
				fd.addDraft(id);
			if ("waste".equals(type))
				fd.addWaste(id);
			instance.sendFeedBack(serverAddress + "/messageDownload?method=feedBack&userId=" + strUserId, fd);
		}
	}

	private void displayFaultInfo() {
		infoBox.setText(faultInfo.toString());
		faultInfo = new StringBuffer(
				"\u4E0B\u5217\u90AE\u4EF6\u8F6C\u79FB\u5931\u8D25,\u8BF7\u91CD\u65B0\u8F6C\u79FB\u6216\u8005\u624B\u5DE5\u5907\u4EFD:\n");
	}

	public boolean fault(String type, Long id, String message) {
		String msg = "\u90AE\u4EF6\u6807\u9898\u4E3A: \"" + message
				+ "\" \u7684\u90AE\u4EF6\u5907\u4EFD\u5931\u8D25,\u662F\u5426\u7EE7\u7EED\u5907\u4EFD\u5176\u4ED6\u90AE\u4EF6?";
		if (pane != null) {
			int value = JOptionPane.showConfirmDialog(pane, msg, "\u63D0\u793A", 0);
			StringBuffer msgError = new StringBuffer("");
			if ("receive".equals(type))
				msgError.append("\u6536\u4EF6\u7BB1:");
			if ("send".equals(type))
				msgError.append("\u53D1\u4EF6\u7BB1:");
			if ("draft".equals(type))
				msgError.append("\u8349\u7A3F\u7BB1:");
			if ("waste".equals(type))
				msgError.append("\u5E9F\u4EF6\u7BB1:");
			msgError.append("\u90AE\u4EF6ID(").append(id.longValue()).append("):\u90AE\u4EF6\u6807\u9898(")
					.append(message).append(")\n");
			faultInfo.append(msgError);
			if (value == 1)
				return false;
		}
		return true;
	}

	public void showProgress(int current, int total) {
		progressBar.setMaximum(total);
		progressBar.setValue(current);
	}

	public void finish(boolean isSuccess) {
		task = null;
		if (isSuccess && jCheckBox.isSelected())
			isClear = true;
		if (isSuccess && progressBar.getValue() == progressBar.getMaximum()) {
			currentProgressBar.setValue(currentProgressBar.getMaximum());
			JOptionPane.showMessageDialog(pane, "\u90AE\u4EF6\u5DF2\u6210\u529F\u8F6C\u79FB\u5230\u672C\u5730!");
		} else {
			JOptionPane.showMessageDialog(pane,
					"\u90AE\u4EF6\u5907\u4EFD\u90E8\u5206\u6210\u529F,\u8BF7\u91CD\u65B0\u5907\u4EFD!");
			displayFaultInfo();
		}
		butLoad.setEnabled(true);
	}

	public boolean isClear() {
		return isClear;
	}

	public void setCurrentProgress(int total) {
		currentProgressBar.setValue(0);
		currentProgressBar.setMaximum(total);
	}

	public void showCurrentProgress(int increaseSize) {
		currentProgressBar.setValue(currentProgressBar.getValue() + increaseSize);
	}
}


/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\enixlin\git\Jrrc_MialClient\lib\Applet.jar
	Total time: 2474 ms
	Jad reported messages/errors:
	Exit status: 0
	Caught exceptions:
*/