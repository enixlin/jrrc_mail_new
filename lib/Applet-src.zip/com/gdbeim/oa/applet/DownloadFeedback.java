/*** Eclipse Class Decompiler plugin, copyright (c) 2012 Chao Chen (cnfree2000@hotmail.com) ***/
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) fieldsfirst noctor radix(10) lradix(10) 
// Source File Name:   DownloadFeedback.java

package com.gdbeim.oa.applet;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DownloadFeedback implements Serializable {

	private static final long serialVersionUID = 5548425631895588265L;
	private List receiveList;
	private List sendList;
	private List draftList;
	private List wasteList;

	public DownloadFeedback() {
		receiveList = new ArrayList();
		sendList = new ArrayList();
		draftList = new ArrayList();
		wasteList = new ArrayList();
	}

	public void addReceive(Long messageid) {
		receiveList.add(messageid);
	}

	public void addSend(Long messageid) {
		sendList.add(messageid);
	}

	public void addDraft(Long messageid) {
		draftList.add(messageid);
	}

	public void addWaste(Long messageid) {
		wasteList.add(messageid);
	}

	public Long[] getReceiveIds() {
		Long result[] = new Long[receiveList.size()];
		for (int i = 0; i < receiveList.size(); i++)
			result[i] = (Long) receiveList.get(i);

		return result;
	}

	public Long[] getSendIds() {
		Long result[] = new Long[sendList.size()];
		for (int i = 0; i < sendList.size(); i++)
			result[i] = (Long) sendList.get(i);

		return result;
	}

	public Long[] getDraftIds() {
		Long result[] = new Long[draftList.size()];
		for (int i = 0; i < draftList.size(); i++)
			result[i] = (Long) draftList.get(i);

		return result;
	}

	public Long[] getWasteIds() {
		Long result[] = new Long[wasteList.size()];
		for (int i = 0; i < wasteList.size(); i++)
			result[i] = (Long) wasteList.get(i);

		return result;
	}
}


/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\enixlin\git\Jrrc_MialClient\lib\Applet.jar
	Total time: 2144 ms
	Jad reported messages/errors:
	Exit status: 0
	Caught exceptions:
*/