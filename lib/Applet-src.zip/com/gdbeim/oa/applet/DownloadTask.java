/*** Eclipse Class Decompiler plugin, copyright (c) 2012 Chao Chen (cnfree2000@hotmail.com) ***/
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) fieldsfirst noctor radix(10) lradix(10) 
// Source File Name:   DownloadTask.java

package com.gdbeim.oa.applet;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DownloadTask implements Serializable {

	private static final long serialVersionUID = 3697346132684098095L;
	private List receiveList;
	private List receiveAttachList;
	private List sendList;
	private List sendAttachList;
	private List draftList;
	private List draftAttachList;
	private List wasteList;
	private List wasteAttachList;

	public DownloadTask() {
		receiveList = new ArrayList(0);
		receiveAttachList = new ArrayList(0);
		sendList = new ArrayList(0);
		sendAttachList = new ArrayList(0);
		draftList = new ArrayList(0);
		draftAttachList = new ArrayList(0);
		wasteList = new ArrayList(0);
		wasteAttachList = new ArrayList(0);
	}

	public List getReceiveList() {
		return receiveList;
	}

	public void setReceiveList(List receiveList) {
		this.receiveList = receiveList;
	}

	public List getReceiveAttachList() {
		return receiveAttachList;
	}

	public void setReceiveAttachList(List receiveAttachList) {
		this.receiveAttachList = receiveAttachList;
	}

	public List getDraftAttachList() {
		return draftAttachList;
	}

	public void setDraftAttachList(List draftAttachList) {
		this.draftAttachList = draftAttachList;
	}

	public List getDraftList() {
		return draftList;
	}

	public void setDraftList(List draftList) {
		this.draftList = draftList;
	}

	public List getSendAttachList() {
		return sendAttachList;
	}

	public void setSendAttachList(List sendAttachList) {
		this.sendAttachList = sendAttachList;
	}

	public List getSendList() {
		return sendList;
	}

	public void setSendList(List sendList) {
		this.sendList = sendList;
	}

	public List getWasteAttachList() {
		return wasteAttachList;
	}

	public void setWasteAttachList(List wasteAttachList) {
		this.wasteAttachList = wasteAttachList;
	}

	public List getWasteList() {
		return wasteList;
	}

	public void setWasteList(List wasteList) {
		this.wasteList = wasteList;
	}

	public long getTotalFileSize() {
		long total = 0L;
		for (int i = 0; i < receiveAttachList.size(); i++) {
			Object obj[] = (Object[]) receiveAttachList.get(i);
			total += ((Long) obj[3]).longValue();
		}

		for (int i = 0; i < sendAttachList.size(); i++) {
			Object obj[] = (Object[]) sendAttachList.get(i);
			total += ((Long) obj[3]).longValue();
		}

		for (int i = 0; i < draftAttachList.size(); i++) {
			Object obj[] = (Object[]) draftAttachList.get(i);
			total += ((Long) obj[3]).longValue();
		}

		for (int i = 0; i < wasteAttachList.size(); i++) {
			Object obj[] = (Object[]) wasteAttachList.get(i);
			total += ((Long) obj[3]).longValue();
		}

		long temp = receiveList.size() + sendList.size() + draftList.size() + wasteList.size();
		total += 30720L * temp;
		return total;
	}

	public boolean isEmpty() {
		boolean isEmpty = false;
		isEmpty = receiveList.size() + receiveAttachList.size() + sendList.size() + sendAttachList.size()
				+ draftList.size() + draftAttachList.size() + wasteList.size() + wasteAttachList.size() == 0;
		return isEmpty;
	}
}


/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\enixlin\git\Jrrc_MialClient\lib\Applet.jar
	Total time: 39 ms
	Jad reported messages/errors:
	Exit status: 0
	Caught exceptions:
*/