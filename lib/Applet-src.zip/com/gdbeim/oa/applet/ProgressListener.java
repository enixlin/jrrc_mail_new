/*** Eclipse Class Decompiler plugin, copyright (c) 2012 Chao Chen (cnfree2000@hotmail.com) ***/
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) fieldsfirst noctor radix(10) lradix(10) 
// Source File Name:   ProgressListener.java

package com.gdbeim.oa.applet;

public interface ProgressListener {

	public abstract void showProgress(int i, int j);

	public abstract void finish(boolean flag);

	public abstract void setCurrentProgress(int i);

	public abstract void showCurrentProgress(int i);

	public abstract boolean fault(String s, Long long1, String s1);

	public abstract void deleteFeedBack(boolean flag, String s, Long long1);
}


/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\enixlin\git\Jrrc_MialClient\lib\Applet.jar
	Total time: 128 ms
	Jad reported messages/errors:
	Exit status: 0
	Caught exceptions:
*/